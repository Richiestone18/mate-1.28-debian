# -*- coding: utf-8 -*-

VERSION = "1.28.0"
PACKAGE = "pluma-plugins"
PACKAGE_STRING = "pluma-plugins 1.28.0"
GETTEXT_PACKAGE = "pluma-plugins"
GP_LOCALEDIR = "/usr/@DATADIRNAME@/locale"
